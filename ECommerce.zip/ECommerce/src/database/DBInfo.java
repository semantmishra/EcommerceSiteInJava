package database;

public interface DBInfo {
	public static final String DATABASE_DRIVER = "com.mysql.jdbc.Driver";
	public static final String DABABASE_URL = "jdbc:mysql://localhost:3306/ecommerce";
	public static final String DATABASE_USER = "root";
	public static final String DATABASE_PASSWORD = "";
}
