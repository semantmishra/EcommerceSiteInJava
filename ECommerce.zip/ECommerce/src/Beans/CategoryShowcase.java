package Beans;

public class CategoryShowcase {
	private String topLeftImg ,topLeftLbl ;
	
	private String bottomLeftImg ,bottomLeftLbl;
	
	private String centerImg ,centerLbl;
	
	private String topRightImg ,topRightLbl;
	
	private String bottomRightImg ,bottomRightLbl;
	
	public String getTopLeftImg() {
		return topLeftImg;
	}

	public void setTopLeftImg(String topLeftImg) {
		this.topLeftImg = topLeftImg;
	}

	public String getTopLeftLbl() {
		return topLeftLbl;
	}

	public void setTopLeftLbl(String topLeftLbl) {
		this.topLeftLbl = topLeftLbl;
	}

	public String getBottomLeftImg() {
		return bottomLeftImg;
	}

	public void setBottomLeftImg(String bottomLeftImg) {
		this.bottomLeftImg = bottomLeftImg;
	}

	public String getBottomLeftLbl() {
		return bottomLeftLbl;
	}

	public void setBottomLeftLbl(String bottomLeftLbl) {
		this.bottomLeftLbl = bottomLeftLbl;
	}

	public String getCenterImg() {
		return centerImg;
	}

	public void setCenterImg(String centerImg) {
		this.centerImg = centerImg;
	}

	public String getCenterLbl() {
		return centerLbl;
	}

	public void setCenterLbl(String centerLbl) {
		this.centerLbl = centerLbl;
	}

	public String getTopRightImg() {
		return topRightImg;
	}

	public void setTopRightImg(String topRightImg) {
		this.topRightImg = topRightImg;
	}

	public String getTopRightLbl() {
		return topRightLbl;
	}

	public void setTopRightLbl(String topRightLbl) {
		this.topRightLbl = topRightLbl;
	}

	public String getBottomRightImg() {
		return bottomRightImg;
	}

	public void setBottomRightImg(String bottomRightImg) {
		this.bottomRightImg = bottomRightImg;
	}

	public String getBottomRightLbl() {
		return bottomRightLbl;
	}

	public void setBottomRightLbl(String bottomRightLbl) {
		this.bottomRightLbl = bottomRightLbl;
	}

	

}
