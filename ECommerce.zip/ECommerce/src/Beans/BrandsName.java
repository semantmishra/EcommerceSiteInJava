package Beans;

public class BrandsName {
		public String brands;	
}
