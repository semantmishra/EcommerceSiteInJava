package Beans;

public class ProductBean {

int id,rating;
public int getRating() {
	return rating;
}

public void setRating(int rating) {
	this.rating = rating;
}

float price;
	public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

	String title, brands,category_name, description,quantity,thumb_pic,front_pic,top_pic,bottom_pic ,left_pic, right_pic;

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBrands() {
		return brands;
	}

	public void setBrands(String brands) {
		this.brands = brands;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getThumb_pic() {
		return thumb_pic;
	}

	public void setThumb_pic(String thumb_pic) {
		this.thumb_pic = thumb_pic;
	}

	public String getFront_pic() {
		return front_pic;
	}

	public void setFront_pic(String front_pic) {
		this.front_pic = front_pic;
	}

	public String getTop_pic() {
		return top_pic;
	}

	public void setTop_pic(String top_pic) {
		this.top_pic = top_pic;
	}

	public String getBottom_pic() {
		return bottom_pic;
	}

	public void setBottom_pic(String bottom_pic) {
		this.bottom_pic = bottom_pic;
	}

	public String getLeft_pic() {
		return left_pic;
	}

	public void setLeft_pic(String left_pic) {
		this.left_pic = left_pic;
	}

	public String getRight_pic() {
		return right_pic;
	}

	public void setRight_pic(String right_pic) {
		this.right_pic = right_pic;
	}

	public float getPrice() {
	return price;
}

public void setPrice(float price) {
	this.price = price;
}

}
