package Beans;

public class DefaultBean {
public int id;
public String name;
}
